==================================================
Libmodbus Client Facade
==================================================

.. literalinclude:: ../../../examples/contrib/libmodbus-client.py

