==================================================
Modbus Scraper Example
==================================================

.. literalinclude:: ../../../examples/contrib/modbus-scraper.py

