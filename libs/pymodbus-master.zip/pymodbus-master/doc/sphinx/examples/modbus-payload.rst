==================================================
Modbus Payload Building/Decoding Example
==================================================

.. literalinclude:: ../../../examples/common/modbus-payload.py

