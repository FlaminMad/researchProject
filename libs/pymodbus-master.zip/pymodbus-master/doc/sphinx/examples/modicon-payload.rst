==================================================
Modicon Encoded Example
==================================================

.. literalinclude:: ../../../examples/contrib/modicon-payload.py

